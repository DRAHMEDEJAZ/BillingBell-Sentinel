import json
from datetime import date
from pathlib import Path
from types import SimpleNamespace

import pytest

from sentinel import verify
from sentinel import audit
from sentinel.cli import run_benchmark
from sentinel.knowledge import load_mue_csv, load_ncci_csv
from sentinel.llm import build_messages, parse_findings
from sentinel.models import normalize_claim
from sentinel.phi import redact
from sentinel.report import to_html, to_text
from sentinel.rules import npi_is_valid

ROOT = Path(__file__).parent.parent
TODAY = date(2026, 10, 25)


def demo(name):
    return json.loads((ROOT / "examples" / f"{name}.json").read_text())


def checks(report):
    return {f["check"] for f in report["flags"]}


# ---------- rule engine ----------

def test_clean_claim():
    report = verify(demo("DEMO-1002"), today=TODAY)
    assert report["status"] == "CLEAN" and report["risk_score"] == 0


def test_demo_1001_holds_for_prior_auth():
    report = verify(demo("DEMO-1001"), today=TODAY)
    assert {"prior_auth", "modifier_25"} <= checks(report)
    assert report["status"] == "HOLD"


def test_demo_1003_catches_many_errors():
    found = checks(verify(demo("DEMO-1003"), today=TODAY))
    assert {"npi", "em_time", "global_period", "new_patient", "modifier_conflict", "ncci_ptp"} <= found


def test_benchmark_suite_passes():
    result = run_benchmark(ROOT / "benchmark" / "cases")
    assert result["passed"] == result["cases"] >= 20
    assert result["f1"] == 1.0


@pytest.mark.parametrize("npi,valid", [("1234567893", True), ("1234567890", False), ("12345", False), ("", False)])
def test_npi_luhn(npi, valid):
    assert npi_is_valid(npi) is valid


def test_messy_input_never_crashes():
    report = verify({"lines": [{"cpt": None, "units": "abc"}], "diagnoses": None, "patient": None}, today=TODAY)
    assert report["status"] == "HOLD"


def test_human_review_always_required():
    assert verify(demo("DEMO-1002"), today=TODAY)["human_review_required"] is True


# ---------- PHI guard ----------

def test_phi_redaction():
    text = "MRN: A123456, DOB: 01/02/1960, call 703-555-0142, ssn 123-45-6789, john@example.com, Woodbridge VA 22191. Billed 72148."
    clean, counts = redact(text)
    for secret in ("A123456", "703-555-0142", "123-45-6789", "john@example.com", "22191", "01/02/1960"):
        assert secret not in clean
    assert "72148" in clean  # procedure codes in notes are kept
    assert counts


def test_note_is_redacted_before_sending():
    claim = normalize_claim(demo("DEMO-1001"))
    messages = build_messages(claim, "Patient phone 703-555-0142. Back pain.")
    assert "703-555-0142" not in messages[1]["content"]
    assert "<note>" in messages[1]["content"]


# ---------- AI layer (fake client, no network) ----------

class FakeClient:
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = 0
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.calls += 1
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=reply))])


AI_REPLY = json.dumps({
    "findings": [
        {"code": "72148", "supported": False, "evidence": "MRI only if no improvement",
         "issue": "MRI was not performed at this visit", "suggested_fix": "Remove the MRI line",
         "severity": "high", "confidence": 0.9},
        {"code": "M54.50", "supported": True, "evidence": "Low back pain", "severity": "low", "confidence": 0.95},
        {"code": "99999", "supported": False, "issue": "invented code", "severity": "high", "confidence": 0.9},
    ],
    "missed_services": [],
})


def test_ai_flags_unsupported_code_and_drops_invented_codes(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)
    client = FakeClient(["```json\n" + AI_REPLY + "\n```"])
    report = verify(demo("DEMO-1001"), note="Back pain. MRI only if no improvement.", today=TODAY, ai_client=client)
    ai_flags = [f for f in report["flags"] if f["source"] == "muse-spark"]
    assert len(ai_flags) == 1 and "72148" in ai_flags[0]["message"]
    assert report["ai_check"]["dropped_findings"] == 1


def test_ai_retries_then_succeeds(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)
    client = FakeClient([TimeoutError("timeout"), "not json", AI_REPLY])
    report = verify(demo("DEMO-1001"), note="note", today=TODAY, ai_client=client)
    assert report["ai_check"]["status"] == "completed" and client.calls == 3


def test_ai_failure_never_blocks_rules(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)
    client = FakeClient([TimeoutError()] * 3)
    report = verify(demo("DEMO-1001"), note="note", today=TODAY, ai_client=client)
    assert report["ai_check"]["status"] == "skipped"
    assert "prior_auth" in checks(report)


def test_no_api_key_skips_ai(monkeypatch):
    monkeypatch.delenv("MODEL_API_KEY", raising=False)
    report = verify(demo("DEMO-1001"), note="note", today=TODAY)
    assert "MODEL_API_KEY" in report["ai_check"]["reason"]


def test_parse_findings_handles_garbage():
    claim = normalize_claim(demo("DEMO-1001"))
    flags, dropped = parse_findings({"findings": ["bad", {"code": "72148", "supported": "unclear",
                                                          "severity": "extreme", "confidence": "x"}]}, claim)
    assert len(flags) == 1 and flags[0].severity == "medium" and dropped == 1


# ---------- audit, reports, loaders ----------

def test_audit_log_detects_tampering(tmp_path):
    log = tmp_path / "audit.jsonl"
    for name in ("DEMO-1001", "DEMO-1002"):
        audit.append(log, verify(demo(name), today=TODAY))
    assert audit.verify_log(log)
    log.write_text(log.read_text().replace('"HOLD"', '"CLEAN"'))
    assert not audit.verify_log(log)


def test_reports_render():
    reports = [verify(demo(n), today=TODAY) for n in ("DEMO-1001", "DEMO-1002", "DEMO-1003")]
    html = to_html(reports)
    assert html.startswith("<!doctype html>") and "DEMO-1003" in html and "<script" not in html
    assert "HOLD" in to_text(reports[0])


def test_official_cms_csv_loaders(tmp_path):
    ncci = tmp_path / "ncci.csv"
    ncci.write_text("Column 1,Column 2,Modifier\n11111,22222,0\n33333,44444,9\n")
    mue = tmp_path / "mue.csv"
    mue.write_text("HCPCS/CPT Code,Practitioner Services MUE Values,MUE Adjudication Indicator\n44950,1,2 Date of Service Edit: Policy\n")
    assert load_ncci_csv(ncci) == {("11111", "22222"): 0}
    assert load_mue_csv(mue) == {"44950": (1, 2)}
