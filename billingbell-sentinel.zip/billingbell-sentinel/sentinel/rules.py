"""Deterministic pre-submission rule engine.

Each rule targets a common denial cause and maps to the Claim Adjustment
Reason Code (CARC) it helps prevent. Rules run offline with no API key.
"""
import re
from datetime import date

from .models import Flag

ICD10_PATTERN = re.compile(r"^[A-TV-Z][0-9][0-9A-Z](\.[0-9A-Z]{1,4})?$")
CPT_PATTERN = re.compile(r"^([0-9]{4}[0-9FTU]|[A-V][0-9]{4})$")  # CPT Cat I/II/III or HCPCS Level II

RULES = []


def rule(func):
    RULES.append(func)
    return func


def _date(value):
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _units(line):
    try:
        return int(line["units"])
    except (TypeError, ValueError):
        return None


def npi_is_valid(npi):
    """NPI check digit uses the Luhn algorithm with the 80840 prefix."""
    npi = str(npi or "")
    if not re.fullmatch(r"[0-9]{10}", npi):
        return False
    digits = [int(d) for d in "80840" + npi[:9]]
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10 == int(npi[9])


@rule
def required_fields(claim, kb, ctx):
    for name in ("claim_id", "date_of_service", "payer", "billing_npi"):
        if not claim.get(name):
            yield Flag("required_fields", "high", f"Missing required field: {name}.",
                       f"Add {name} before submission.", carc="16")
    if not claim["lines"]:
        yield Flag("required_fields", "high", "Claim has no service lines.", "Add at least one service line.", carc="16")
    if not claim["diagnoses"]:
        yield Flag("required_fields", "high", "Claim has no diagnosis codes.", "Add the supporting diagnoses.", carc="16")


@rule
def npi_check(claim, kb, ctx):
    for field_name in ("billing_npi", "rendering_npi"):
        value = claim.get(field_name)
        if value and not npi_is_valid(value):
            yield Flag("npi", "high", f"{field_name} '{value}' fails the NPI check-digit test.",
                       "Confirm the NPI in NPPES.", carc="16")


@rule
def eligibility(claim, kb, ctx):
    dos = _date(claim.get("date_of_service"))
    patient = claim["patient"]
    if not dos:
        if claim.get("date_of_service"):
            yield Flag("eligibility", "high", "Date of service is not in YYYY-MM-DD format.",
                       "Correct the date of service.", carc="16")
        return
    start = _date(patient.get("coverage_start"))
    end = _date(patient.get("coverage_end"))
    if (start and dos < start) or (end and dos > end):
        yield Flag("eligibility", "high", "Coverage is not active on the date of service.",
                   "Re-verify eligibility or bill the correct payer.", carc="27")
    if not start and not end:
        yield Flag("eligibility", "low", "No coverage dates on file for this patient.",
                   "Run a real-time eligibility check before submission.", carc="27")


@rule
def timely_filing(claim, kb, ctx):
    dos = _date(claim.get("date_of_service"))
    if not dos:
        return
    limit = kb.payer_rules(claim.get("payer"))["timely_filing_days"]
    age = (ctx["today"] - dos).days
    if age > limit:
        yield Flag("timely_filing", "high", f"Service is {age} days old; the payer limit is {limit} days.",
                   "Check for proof of timely filing or an exception before submitting.", carc="29")
    elif age > limit - 14:
        yield Flag("timely_filing", "medium", f"Only {limit - age} days remain in the filing window.",
                   "Submit this claim first.", carc="29")


@rule
def diagnosis_codes(claim, kb, ctx):
    seen = set()
    for dx in claim["diagnoses"]:
        if not ICD10_PATTERN.match(dx):
            yield Flag("icd10_format", "high", f"'{dx}' is not a valid ICD-10-CM format.",
                       "Correct the diagnosis code.", carc="16")
        if dx in seen:
            yield Flag("icd10_duplicate", "low", f"Diagnosis {dx} is listed twice.", "Remove the duplicate.", carc="16")
        seen.add(dx)


@rule
def line_basics(claim, kb, ctx):
    dx_count = len(claim["diagnoses"])
    for i, line in enumerate(claim["lines"], start=1):
        cpt = line["cpt"]
        if not CPT_PATTERN.match(cpt):
            yield Flag("cpt_format", "high", f"'{cpt}' is not a valid CPT/HCPCS format.",
                       "Correct the procedure code.", carc="16", line=i)
        units = _units(line)
        if units is None or units < 1:
            yield Flag("units", "high", "Units must be a whole number of at least 1.",
                       "Enter the units billed.", carc="16", line=i)
        pointers = line["diagnosis_pointers"]
        if not pointers:
            yield Flag("dx_pointer", "medium", f"No diagnosis linked to {cpt}.",
                       "Link the line to the diagnosis that supports it.", carc="11", line=i)
        for p in pointers:
            if not isinstance(p, int) or p < 1 or p > dx_count:
                yield Flag("dx_pointer", "high", f"Diagnosis pointer {p} does not match a diagnosis on the claim.",
                           "Fix the pointer to reference a listed diagnosis.", carc="16", line=i)
        if len(pointers) > 4:
            yield Flag("dx_pointer", "medium", "More than 4 diagnosis pointers on one line.",
                       "Keep the 4 most relevant diagnoses.", carc="16", line=i)
        charge = line.get("charge")
        if charge is not None and (not isinstance(charge, (int, float)) or charge <= 0):
            yield Flag("charge", "medium", "Line charge is missing, zero or negative.",
                       "Enter the practice's charge for this service.", carc="16", line=i)


@rule
def modifiers(claim, kb, ctx):
    known = set(kb.reference["known_modifiers"])
    for i, line in enumerate(claim["lines"], start=1):
        mods = line["modifiers"]
        for m in mods:
            if m not in known:
                yield Flag("modifier_unknown", "low", f"Modifier '{m}' is not in the reference list.",
                           "Confirm the modifier is valid for this code and payer.", carc="4", line=i)
        for a, b in kb.reference["conflicting_modifier_pairs"]:
            if a in mods and b in mods:
                yield Flag("modifier_conflict", "high", f"Modifiers {a} and {b} conflict on the same line.",
                           "Split into separate lines or remove one modifier.", carc="4", line=i)


@rule
def duplicate_lines(claim, kb, ctx):
    seen = {}
    for i, line in enumerate(claim["lines"], start=1):
        key = (line["cpt"], tuple(sorted(line["modifiers"])))
        if key in seen and not {"76", "77", "91"} & set(line["modifiers"]):
            yield Flag("duplicate_line", "high", f"{line['cpt']} repeats line {seen[key]} with the same modifiers.",
                       "Combine units on one line, or add a repeat-service modifier if documented.", carc="18", line=i)
        seen.setdefault(key, i)


@rule
def prior_authorization(claim, kb, ctx):
    codes = set(kb.payer_rules(claim.get("payer"))["prior_auth_codes"])
    if claim.get("prior_auth_number"):
        return
    for i, line in enumerate(claim["lines"], start=1):
        if line["cpt"] in codes:
            yield Flag("prior_auth", "high", f"{line['cpt']} requires prior authorization for this payer, "
                       "and no authorization number is on the claim.",
                       "Obtain the authorization and add the number.", carc="197", line=i)


@rule
def ncci_ptp(claim, kb, ctx):
    distinct = set(kb.reference["distinct_service_modifiers"])
    lines = list(enumerate(claim["lines"], start=1))
    for i, first in lines:
        for j, second in lines:
            indicator = kb.ncci.get((first["cpt"], second["cpt"]))
            if indicator is None or i == j:
                continue
            has_bypass = bool(distinct & set(second["modifiers"]))
            if indicator == 0:
                yield Flag("ncci_ptp", "high",
                           f"NCCI edit: {second['cpt']} is bundled into {first['cpt']} and cannot be unbundled.",
                           f"Remove {second['cpt']}; a modifier will not bypass this edit.", carc="97", line=j)
            elif indicator == 1 and not has_bypass:
                yield Flag("ncci_ptp", "medium",
                           f"NCCI edit: {second['cpt']} is bundled into {first['cpt']}.",
                           "If the note documents a distinct service, add 59/XE/XS/XP/XU to "
                           f"{second['cpt']}; otherwise remove it.", carc="97", line=j)


@rule
def medically_unlikely_edits(claim, kb, ctx):
    per_day = {}
    for i, line in enumerate(claim["lines"], start=1):
        units = _units(line) or 0
        edit = kb.mue.get(line["cpt"])
        if not edit:
            continue
        limit, mai = edit
        if mai == 1 and units > limit:
            yield Flag("mue", "high", f"{units} units of {line['cpt']} exceeds the per-line MUE of {limit}.",
                       "Correct the units, or split onto separate lines with the proper modifier if documented.",
                       carc="151", line=i)
        per_day[line["cpt"]] = per_day.get(line["cpt"], 0) + units
    for code, total in per_day.items():
        limit, mai = kb.mue[code]
        if mai in (2, 3) and total > limit:
            note = "MAI 2 edits cannot be appealed." if mai == 2 else "Payable only with strong documentation."
            yield Flag("mue", "high", f"{total} units of {code} on this date exceeds the MUE of {limit}. {note}",
                       "Correct the units before submission.", carc="151")


@rule
def em_rules(claim, kb, ctx):
    ref = kb.reference
    em_codes = kb.em_codes
    codes = [line["cpt"] for line in claim["lines"]]
    has_procedure = any(not c.startswith("99") for c in codes)  # 99xxx = E/M, preventive, prolonged
    dos = _date(claim.get("date_of_service"))
    patient = claim["patient"]

    for i, line in enumerate(claim["lines"], start=1):
        cpt, mods = line["cpt"], set(line["modifiers"])
        if cpt not in em_codes:
            continue

        if has_procedure and "25" not in mods:
            yield Flag("modifier_25", "medium", f"E/M {cpt} is billed with a procedure on the same day without modifier 25.",
                       "Add 25 only if the note documents a significant, separately identifiable E/M service.",
                       carc="4", line=i)

        last_visit = _date(patient.get("last_visit_date"))
        if cpt in ref["em_new"] and last_visit and dos and (dos - last_visit).days < 3 * 365:
            yield Flag("new_patient", "high", f"New-patient code {cpt} billed, but the patient was seen within 3 years.",
                       "Use the matching established-patient code.", carc="16", line=i)

        global_end = _date(patient.get("global_period_end"))
        if global_end and dos and dos <= global_end and not mods & set(ref["global_period_modifiers"]):
            yield Flag("global_period", "high", f"E/M {cpt} falls inside a surgical global period without 24, 25, 57 or 79.",
                       "Post-op care is included in the surgery; add a modifier only if the visit was unrelated.",
                       carc="97", line=i)

        minutes = claim.get("em_total_time_minutes")
        time_range = ref["em_time_ranges"].get(cpt)
        if claim.get("em_basis") == "time" and isinstance(minutes, (int, float)) and time_range:
            low, high = time_range
            if minutes < low:
                yield Flag("em_time", "high", f"{cpt} needs at least {low} minutes; {minutes} documented (possible overcoding).",
                           "Choose the level that matches the documented time.", carc="150", line=i)
            elif minutes > high and cpt not in ("99205", "99215"):
                yield Flag("em_time", "low", f"{minutes} minutes supports a higher level than {cpt} (possible undercoding).",
                           "Review the level; the practice may be under-billing.", line=i)


@rule
def age_conflicts(claim, kb, ctx):
    age = claim["patient"].get("age")
    if not isinstance(age, int):
        return
    bands = kb.reference["preventive_age_bands"]
    for i, line in enumerate(claim["lines"], start=1):
        band = bands.get(line["cpt"])
        if band and not (band[0] <= age <= band[1]):
            yield Flag("age_conflict", "high", f"Preventive code {line['cpt']} is for ages {band[0]}-{band[1]}; patient is {age}.",
                       "Select the preventive code for the patient's age band.", carc="6", line=i)


def run_rules(claim, kb, today):
    ctx = {"today": today}
    flags = []
    for check in RULES:
        flags.extend(check(claim, kb, ctx))
    return flags
