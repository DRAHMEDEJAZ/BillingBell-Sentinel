"""Loads the coding knowledge base: NCCI edits, MUEs, payer rule packs, coding reference.

Sample data ships with the project. For production, load the official quarterly
CMS NCCI and MUE files with load_ncci_csv() and load_mue_csv().
"""
import csv
import json
from functools import lru_cache
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"


def _load_json(name):
    return json.loads((DATA_DIR / name).read_text(encoding="utf-8"))


class KnowledgeBase:
    def __init__(self, ncci=None, mue=None, payers=None, reference=None):
        self.reference = reference or _load_json("coding_reference.json")
        self.payers = payers or _load_json("payers.json")
        self.ncci = ncci if ncci is not None else {
            (p["column1"], p["column2"]): int(p["modifier_indicator"])
            for p in _load_json("ncci_ptp_sample.json")["pairs"]
        }
        self.mue = mue if mue is not None else {
            e["code"]: (int(e["max_units"]), int(e["mai"]))
            for e in _load_json("mue_sample.json")["edits"]
        }

    def payer_rules(self, payer):
        rules = dict(self.payers["default"])
        rules.update(self.payers.get(payer, {}))
        return rules

    @property
    def em_codes(self):
        return set(self.reference["em_new"]) | set(self.reference["em_established"])


def load_ncci_csv(path, column1="Column 1", column2="Column 2", indicator="Modifier"):
    """Load an official CMS NCCI PTP table exported to CSV. Rows whose indicator is 9 are skipped."""
    pairs = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            ind = str(row.get(indicator, "")).strip()
            if ind in {"0", "1"}:
                pairs[(row[column1].strip(), row[column2].strip())] = int(ind)
    return pairs


def load_mue_csv(path, code="HCPCS/CPT Code", value="Practitioner Services MUE Values", mai="MUE Adjudication Indicator"):
    """Load an official CMS practitioner MUE table exported to CSV."""
    edits = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            try:
                edits[row[code].strip()] = (int(row[value]), int(str(row[mai]).strip()[0]))
            except (KeyError, ValueError):
                continue
    return edits


@lru_cache(maxsize=1)
def default_knowledge():
    return KnowledgeBase()
