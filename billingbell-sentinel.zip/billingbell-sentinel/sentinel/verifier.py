"""Runs all checks on a claim and builds the verification report."""
import hashlib
import json
from datetime import date, datetime, timezone

from . import __version__
from .knowledge import default_knowledge
from .llm import AIUnavailable, ai_check
from .models import SEVERITY_WEIGHT, normalize_claim
from .rules import run_rules


def risk_score(flags):
    """0 = clean, 100 = almost certain denial."""
    return min(100, sum(SEVERITY_WEIGHT.get(f.severity, 0) * (f.confidence or 1) for f in flags))


def verify(raw_claim, note="", kb=None, today=None, use_ai=True, ai_client=None):
    kb = kb or default_knowledge()
    today = today or date.today()
    claim = normalize_claim(raw_claim)

    flags = run_rules(claim, kb, today)
    ai_info = {"status": "skipped", "reason": "no clinical note provided"}
    if note and use_ai:
        try:
            ai_flags, info = ai_check(claim, note, client=ai_client)
            flags += ai_flags
            ai_info = {"status": "completed", **info}
        except AIUnavailable as error:
            ai_info = {"status": "skipped", "reason": str(error)}
    elif note:
        ai_info = {"status": "skipped", "reason": "AI disabled"}

    order = {"high": 0, "medium": 1, "low": 2}
    flags.sort(key=lambda f: (order.get(f.severity, 3), f.line, f.check))
    score = round(risk_score(flags))

    if any(f.severity == "high" for f in flags):
        status = "HOLD"
    elif flags:
        status = "REVIEW"
    else:
        status = "CLEAN"

    return {
        "claim_id": claim.get("claim_id"),
        "payer": claim.get("payer"),
        "status": status,
        "risk_score": score,
        "flag_count": len(flags),
        "flags": [f.to_dict() for f in flags],
        "ai_check": ai_info,
        "human_review_required": True,
        "audit": {
            "sentinel_version": __version__,
            "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "claim_sha256": hashlib.sha256(json.dumps(raw_claim, sort_keys=True).encode()).hexdigest(),
            "decision": "pending biller review",
        },
    }


STATUS_TEXT = {
    "CLEAN": "No issues found. Ready for biller sign-off.",
    "REVIEW": "Biller decision needed before submission.",
    "HOLD": "Do not submit. Fix the high-severity issues first.",
}
