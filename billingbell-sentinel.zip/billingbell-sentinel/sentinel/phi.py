"""PHI guard: redacts common identifiers before any text leaves the practice.

This is a safety net, not a complete HIPAA de-identification tool. It removes
pattern-based identifiers from the HIPAA Safe Harbor list (SSNs, phone and fax
numbers, emails, URLs, IP addresses, record/account numbers, full dates and ZIP
codes). Names and free-text addresses still need de-identification upstream.
"""
import re

PATTERNS = [
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
    ("URL", re.compile(r"\bhttps?://\S+|\bwww\.\S+", re.I)),
    ("IP", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("PHONE", re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}\b")),
    ("MRN", re.compile(r"\b(?:MRN|Medical Record|Account|Acct|Member ID|Policy)\s*(?:#|No\.?|Number)?\s*[:#]?\s*[A-Z0-9-]{4,}\b", re.I)),
    ("DATE", re.compile(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b")),
    ("DOB", re.compile(r"\b(?:DOB|Date of Birth)\s*[:#]?\s*\S+", re.I)),
    # ZIP only next to a state or "ZIP" label, so 5-digit CPT codes in notes are kept.
    ("ZIP", re.compile(r"\b(?:[A-Z]{2}|ZIP(?: code)?:?)\s+\d{5}(?:-\d{4})?\b")),
]


def redact(text):
    """Return (redacted_text, counts) where counts maps identifier type to matches removed."""
    counts = {}
    for label, pattern in PATTERNS:
        text, n = pattern.subn(f"[{label}]", text)
        if n:
            counts[label] = n
    return text, counts
