"""Text and HTML reports for billers."""
from html import escape

from .verifier import STATUS_TEXT

TAG = {"high": "HIGH", "medium": "MED ", "low": "LOW "}


def to_text(report):
    out = [
        f"BillingBell Sentinel | claim {report['claim_id']} | {report['payer']}",
        f"Status: {report['status']} - {STATUS_TEXT[report['status']]}",
        f"Risk score: {report['risk_score']}/100   AI check: {report['ai_check']['status']}"
        + (f" ({report['ai_check'].get('reason')})" if report['ai_check'].get('reason') else ""),
        "",
    ]
    for f in report["flags"]:
        where = f"line {f['line']}" if f["line"] else "claim"
        carc = f" CARC {f['carc']}" if f["carc"] else ""
        out.append(f"[{TAG[f['severity']]}] ({where}) {f['message']}")
        out.append(f"        Fix: {f['suggested_fix']}  [{f['source']}{carc}]")
        if f.get("evidence"):
            out.append(f"        Evidence: \"{f['evidence']}\"")
    if not report["flags"]:
        out.append("No issues found.")
    out.append("\nA person must review and approve every claim before submission.")
    return "\n".join(out)


CSS = """
:root{--ink:#0E1830;--muted:#5b6478;--line:#e3e6ee;--bg:#f6f7fb;--card:#fff;
--high:#b42318;--high-bg:#fee4e2;--med:#a15c07;--med-bg:#fef0c7;--low:#175cd3;--low-bg:#e0eaff;--ok:#067647;--ok-bg:#dcfae6}
@media (prefers-color-scheme:dark){:root{--ink:#e8ebf3;--muted:#9aa3b5;--line:#2a3247;--bg:#0b1120;--card:#121a2c;
--high:#fda29b;--high-bg:#3d1714;--med:#fec84b;--med-bg:#3a2a06;--low:#84adff;--low-bg:#102a56;--ok:#75e0a7;--ok-bg:#0b3320}}
*{box-sizing:border-box}body{margin:0;font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--ink)}
main{max-width:960px;margin:0 auto;padding:24px 16px}h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:0}
.sub{color:var(--muted);margin:0 0 20px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px}
.head{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}
.pill{font-weight:600;font-size:12px;padding:3px 10px;border-radius:999px}
.HOLD,.high{color:var(--high);background:var(--high-bg)}.REVIEW,.medium{color:var(--med);background:var(--med-bg)}
.low{color:var(--low);background:var(--low-bg)}.CLEAN{color:var(--ok);background:var(--ok-bg)}
.meta{color:var(--muted);font-size:13px}.flag{border-top:1px solid var(--line);padding:12px 0}
.flag p{margin:4px 0}.ev{font-style:italic;color:var(--muted)}.bar{height:8px;background:var(--line);border-radius:4px;overflow:hidden;width:140px}
.bar span{display:block;height:100%;background:var(--high)}footer{color:var(--muted);font-size:12px;margin-top:24px}
"""


def _card(report):
    flags = "".join(
        f"""<div class="flag"><span class="pill {escape(f['severity'])}">{escape(f['severity'].upper())}</span>
<span class="meta"> {'Line ' + str(f['line']) if f['line'] else 'Claim'} · {escape(f['check'])} · {escape(f['source'])}{' · CARC ' + escape(f['carc']) if f['carc'] else ''}</span>
<p><strong>{escape(f['message'])}</strong></p><p>Fix: {escape(f['suggested_fix'])}</p>
{f'<p class="ev">Evidence: “{escape(f["evidence"])}”</p>' if f.get('evidence') else ''}</div>"""
        for f in report["flags"]
    ) or '<p class="meta">No issues found.</p>'
    ai = report["ai_check"]
    return f"""<section class="card"><div class="head"><div><h2>Claim {escape(str(report['claim_id']))}</h2>
<div class="meta">{escape(str(report['payer']))} · AI check: {escape(ai['status'])}{' (' + escape(ai.get('reason', '')) + ')' if ai.get('reason') else ''}</div></div>
<div style="text-align:right"><span class="pill {report['status']}">{report['status']}</span>
<div class="meta">Risk {report['risk_score']}/100</div><div class="bar"><span style="width:{report['risk_score']}%"></span></div></div></div>
<p>{escape(STATUS_TEXT[report['status']])}</p>{flags}</section>"""


def to_html(reports):
    reports = reports if isinstance(reports, list) else [reports]
    held = sum(r["status"] == "HOLD" for r in reports)
    review = sum(r["status"] == "REVIEW" for r in reports)
    clean = sum(r["status"] == "CLEAN" for r in reports)
    body = "".join(_card(r) for r in reports)
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sentinel Claim Report</title><style>{CSS}</style></head><body><main>
<h1>BillingBell Sentinel™ claim report</h1>
<p class="sub">{len(reports)} claim(s) · {held} hold · {review} review · {clean} clean</p>{body}
<footer>A trained person must review and approve every claim. Sentinel does not make clinical decisions.
Research prototype by BillingBell Healthcare Systems. CPT® is a registered trademark of the American Medical Association.</footer>
</main></body></html>"""
