"""Command-line interface.

  python -m sentinel check  CLAIM.json [NOTE.txt] [--html out.html] [--json] [--no-ai]
  python -m sentinel batch  FOLDER [--html out.html] [--no-ai]
  python -m sentinel benchmark [FOLDER]
  python -m sentinel verify-log audit_log.jsonl
"""
import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path

from . import audit
from .report import to_html, to_text
from .verifier import verify


def _load_env(path=".env"):
    if Path(path).exists():
        for line in Path(path).read_text().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())


def _read_note(path):
    return Path(path).read_text(encoding="utf-8") if path and Path(path).exists() else ""


def cmd_check(args):
    claim = json.loads(Path(args.claim).read_text(encoding="utf-8"))
    report = verify(claim, _read_note(args.note), use_ai=not args.no_ai)
    print(json.dumps(report, indent=2) if args.json else to_text(report))
    if args.html:
        Path(args.html).write_text(to_html(report), encoding="utf-8")
        print(f"\nHTML report: {args.html}")
    if args.audit_log:
        audit.append(args.audit_log, report)
    return 2 if report["status"] == "HOLD" else 0


def cmd_batch(args):
    reports = []
    for claim_path in sorted(Path(args.folder).glob("*.json")):
        claim = json.loads(claim_path.read_text(encoding="utf-8"))
        if "claim_id" not in claim:
            continue
        report = verify(claim, _read_note(claim_path.with_suffix(".txt")), use_ai=not args.no_ai)
        reports.append(report)
        if args.audit_log:
            audit.append(args.audit_log, report)
        print(f"{report['status']:7} risk {report['risk_score']:>3}  {report['claim_id']}  ({report['flag_count']} flags)")
    if args.html:
        Path(args.html).write_text(to_html(reports), encoding="utf-8")
        print(f"\nHTML report: {args.html}")
    return 0


def run_benchmark(folder):
    tp = fp = fn = 0
    rows = []
    for case_path in sorted(Path(folder).glob("*.json")):
        case = json.loads(case_path.read_text(encoding="utf-8"))
        today = date.fromisoformat(case.get("today", "2026-10-25"))
        report = verify(case["claim"], use_ai=False, today=today)
        found = {f["check"] for f in report["flags"]}
        expected = set(case["expected_checks"])
        tp += len(found & expected)
        fp += len(found - expected)
        fn += len(expected - found)
        rows.append((case_path.stem, expected == found, sorted(expected - found), sorted(found - expected)))
    precision = tp / (tp + fp) if tp + fp else 1.0
    recall = tp / (tp + fn) if tp + fn else 1.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"cases": len(rows), "passed": sum(r[1] for r in rows), "precision": precision,
            "recall": recall, "f1": f1, "rows": rows}


def cmd_benchmark(args):
    result = run_benchmark(args.folder)
    for name, ok, missed, extra in result["rows"]:
        detail = "" if ok else f"  missed={missed} extra={extra}"
        print(f"{'PASS' if ok else 'FAIL'}  {name}{detail}")
    print(f"\n{result['passed']}/{result['cases']} cases exact match | precision {result['precision']:.2f} | "
          f"recall {result['recall']:.2f} | F1 {result['f1']:.2f}")
    return 0 if result["passed"] == result["cases"] else 1


def cmd_verify_log(args):
    ok = audit.verify_log(args.log)
    print("Audit log intact." if ok else "WARNING: audit log has been altered.")
    return 0 if ok else 1


def main(argv=None):
    _load_env()
    parser = argparse.ArgumentParser(prog="sentinel", description="BillingBell Sentinel claim verification")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("check", help="verify one claim")
    p.add_argument("claim")
    p.add_argument("note", nargs="?")
    p.add_argument("--html")
    p.add_argument("--json", action="store_true")
    p.add_argument("--no-ai", action="store_true")
    p.add_argument("--audit-log")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("batch", help="verify every claim in a folder (NOTE = same name .txt)")
    p.add_argument("folder")
    p.add_argument("--html")
    p.add_argument("--no-ai", action="store_true")
    p.add_argument("--audit-log")
    p.set_defaults(func=cmd_batch)

    p = sub.add_parser("benchmark", help="measure rule accuracy on labeled cases")
    p.add_argument("folder", nargs="?", default="benchmark/cases")
    p.set_defaults(func=cmd_benchmark)

    p = sub.add_parser("verify-log", help="check that the audit log has not been altered")
    p.add_argument("log")
    p.set_defaults(func=cmd_verify_log)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
