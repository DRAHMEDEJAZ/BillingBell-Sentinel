"""Claim normalization and the Flag record."""
from dataclasses import asdict, dataclass, field

SEVERITY_WEIGHT = {"high": 35, "medium": 15, "low": 5}


@dataclass
class Flag:
    check: str
    severity: str  # high | medium | low
    message: str
    suggested_fix: str
    carc: str = ""  # Claim Adjustment Reason Code this flag helps prevent
    line: int = 0  # 0 = whole claim
    source: str = "rule"  # rule | muse-spark
    evidence: str = ""
    confidence: float = 1.0
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        data = asdict(self)
        if not data["extra"]:
            data.pop("extra")
        return data


def normalize_claim(raw):
    """Return a cleaned copy of the claim so rules never crash on messy input."""
    claim = dict(raw)
    claim["patient"] = dict(raw.get("patient") or {})
    claim["diagnoses"] = [str(d).strip().upper() for d in raw.get("diagnoses") or []]
    lines = []
    for line in raw.get("lines") or []:
        lines.append({
            "cpt": str(line.get("cpt", "")).strip().upper(),
            "modifiers": [str(m).strip().upper() for m in line.get("modifiers") or []],
            "units": line.get("units", 1),
            "diagnosis_pointers": list(line.get("diagnosis_pointers") or []),
            "charge": line.get("charge"),
        })
    claim["lines"] = lines
    return claim
