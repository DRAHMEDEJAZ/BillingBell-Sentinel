"""Append-only audit log. Each entry is chained to the previous one by hash,
so any later edit to the log is detectable with verify_log()."""
import hashlib
import json
from pathlib import Path


def _hash(entry):
    return hashlib.sha256(json.dumps(entry, sort_keys=True).encode()).hexdigest()


def append(log_path, report, decision="pending biller review", reviewer=""):
    path = Path(log_path)
    previous = "0" * 64
    if path.exists():
        lines = path.read_text(encoding="utf-8").strip().splitlines()
        if lines:
            previous = json.loads(lines[-1])["entry_hash"]
    entry = {
        "claim_id": report["claim_id"],
        "status": report["status"],
        "risk_score": report["risk_score"],
        "flags": [f["check"] for f in report["flags"]],
        "claim_sha256": report["audit"]["claim_sha256"],
        "checked_at": report["audit"]["checked_at"],
        "decision": decision,
        "reviewer": reviewer,
        "previous_hash": previous,
    }
    entry["entry_hash"] = _hash(entry)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    return entry


def verify_log(log_path):
    """Return True if no entry in the log has been altered or removed."""
    previous = "0" * 64
    for line in Path(log_path).read_text(encoding="utf-8").strip().splitlines():
        entry = json.loads(line)
        stored = entry.pop("entry_hash")
        if entry["previous_hash"] != previous or _hash(entry) != stored:
            return False
        previous = stored
    return True
