"""BillingBell Sentinel: verify AI-generated healthcare billing actions before submission."""
__version__ = "1.0.0"

from .verifier import verify  # noqa: E402

__all__ = ["verify", "__version__"]
